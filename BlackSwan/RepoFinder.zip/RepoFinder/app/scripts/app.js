define(['angular'],
        function (angular) {
            'use strict';
            return angular
                    .module('repoFinderApp', ['ngRoute', 'ngResource', 'ngTouch']);
        });
