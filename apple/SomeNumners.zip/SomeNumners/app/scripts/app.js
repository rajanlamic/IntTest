define(['angular'],
        function (angular) {
            'use strict';
            return angular
                    .module('someNumbersApp', ['ngRoute', 'ngResource']);
        });
